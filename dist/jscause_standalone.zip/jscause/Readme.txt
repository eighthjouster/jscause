Thank you for using the JSCause Framework!

Your website is on the sites/mysite directory.

How to use:

*********************************************************
* Scenario 1:  If you downloaded the standalone version *
*********************************************************

On a terminal window, go to the directory this Readmefile is located at, then run:

node jscause.js

Then open a browser window and navigate to: https://localhost:3000

**************************************************
* Scenario 2:  If you installed JSCause via NPM: *
**************************************************

On a terminal window, go to the directory this Readmefile is located at, then run:

jscause

Then open a browser window and navigate to: https://localhost:3000

*********************************************************************

For more information, visit:  https://www.jscause.org

- Eightjouster
